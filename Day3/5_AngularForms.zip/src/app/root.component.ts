import { Component, AfterContentInit, AfterViewInit, ViewChild } from "@angular/core";

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Forms</h1>
            </div>
            
            <!-- <model-based></model-based> -->
            <!-- <templated></templated> -->
            <reactive-form></reactive-form>
        </div>
    `
})
export class RootComponent implements AfterViewInit {
    constructor() {
    }

    ngAfterViewInit(): void {
    }
}