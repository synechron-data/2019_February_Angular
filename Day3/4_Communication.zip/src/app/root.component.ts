import { Component, AfterContentInit, AfterViewInit, ViewChild } from "@angular/core";
import { CounterComponent } from "./counter/counter.component";

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Communication</h1>
            </div>
            
            <!-- <list [personList]=pList></list> -->

            <!-- <counter [interval]=10></counter>
            <counter></counter>  -->

            <!-- <counter [interval]=10 #c1></counter>  -->

            <h2 *ngIf=message class="alert alert-danger">{{message}}</h2>

            <counter #c1 (onMax)=doUpdate($event)></counter>  

            <br/><br/>
            <div class="row">
                <div class="col-md-2">
                    <button class="btn btn-warning btn-block" (click)=c1.reset()>Parent Reset</button>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-warning btn-block" (click)=p_reset(c1)>Parent Reset</button>
                </div>
            </div>
        </div>
    `
})
export class RootComponent implements AfterViewInit {
    pList: Array<string>;
    message: string;

    @ViewChild(CounterComponent)
    counter: CounterComponent;

    constructor() {
        this.message = "";
        this.pList = ["Manish", "Abhijeet", "Abhishek", "Kedar", "Sumeet"];
    }

    ngAfterViewInit(): void {
        // console.log(this.counter);
        this.counter.interval = 100;
    }

    p_reset(c: CounterComponent) {
        c.reset();
    }

    doUpdate(f: boolean) {
        console.log(f);
        if (f) {
            this.message = "Max Click Reached, reset to continue....";
        } else {
            this.message = "";
        }
    }
}