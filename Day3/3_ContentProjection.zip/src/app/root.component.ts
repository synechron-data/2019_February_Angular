import { Component, AfterContentInit, AfterViewInit } from "@angular/core";

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Content Projection</h1>
            </div>
            
            <!-- <input type="text" (input)="doChange()"/> -->
            <!-- <icon-input>
                <input type="number"/>
            </icon-input> -->

            <icon-input>
                <input type="number" class="a"/>
                <input type="text" class="b"/>
            </icon-input>
        </div>
    `
})
export class RootComponent {
    constructor() {
    }

    doChange() {
        console.log("Input Event Fired...");
    }
}