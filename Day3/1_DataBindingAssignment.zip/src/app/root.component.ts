import { Component, AfterContentInit, AfterViewInit } from "@angular/core";

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Data Binding</h1>
            </div>

            <!-- <assign-one></assign-one> -->
            <assign-two></assign-two>
        </div>
    `
})
export class RootComponent {
    constructor() {
    }
}