import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { RootComponent } from "./root.component";
import { COneComponent } from "./c-one/c-one.component";
import { CTwoComponent } from "./c-two/c-two.component";

@NgModule({
    imports: [BrowserModule],
    declarations: [RootComponent, COneComponent, CTwoComponent],
    bootstrap: [RootComponent]
})
export class RootModule { }