import { Component, AfterContentInit, AfterViewInit } from "@angular/core";

@Component({
    selector: 'root',
    template: `
        <style>
            .d {
                border: 2px solid red;
            }
        </style>
        <div class="container">
            <div class="row">
                <h1 class="text-info">Data Binding</h1>
            </div>

            <div>
                <h2 class="text-success">Two Way Binding</h2>
                <h3>Message: {{message}}</h3>
                <input type="text" bindon-ngModel=message/>
                <input type="text" [(ngModel)]=message/>
                <input type="text" [(ngModel)]=message [ngModelOptions]="{updateOn: 'blur'}"/>
                <br/>
                <input type="text" [(ngModel)]=city/>
                <h4>You are from: {{city}}</h4>
                <br/>
                <br/>
                <input type="text" [(ngModel)]=name (change)=doUpdate(name) (blur)=doBlur()/>
                <input type="text" [(ngModel)]=name (input)=doUpdate(name) />
            </div>

            <div [hidden]=flag>
                <h2 class="text-success">Event Binding</h2>
                <h3>Message: {{message}}</h3>

                <button class="btn btn-info" on-click=doChange()>Click</button>
                <button class="btn btn-info" (click)=doChange()>Click</button>
                <button class="btn btn-success" id="b1">Click - JS</button>
            </div>

            <div [hidden]=flag>
                <div class="d" [attr.height]=height>
                
                </div>
                <h2 class="text-success">Property Binding</h2>
                <h3>Message: {{message}}</h3>
                <input type="text" value={{message}}/>
                <h3 innerHTML={{message}}>Message:</h3>
                <h3 bind-innerHTML=message>Message:</h3>
                <h3 [innerHTML]=message>
                    Message:
                </h3>
                <input type="text" [value]=message/>
            </div>
        </div>
    `
})
export class RootComponent implements AfterViewInit {
    ngAfterViewInit(): void {
        document.getElementById("b1").addEventListener("click", () => {
            this.message = new Date().toTimeString();
        });
    }

    message: string;
    height: number;
    width: number;
    flag: boolean;

    constructor() {
        this.message = "Hello";
        this.height = 200;
        this.width = 200;
        this.flag = true;
    }

    doChange() {
        this.message = new Date().toTimeString();
    }

    doUpdate(name: string) {
        this.message = "Name is: " + name;
        console.log("Change Event");
    }

    doBlur(){
        console.log("Blur Event");
    }
}