import 'core-js/es6';
import 'core-js/es7/reflect';
import 'zone.js/dist/zone';
import '@webcomponents/webcomponentsjs/custom-elements-es5-adapter.js'