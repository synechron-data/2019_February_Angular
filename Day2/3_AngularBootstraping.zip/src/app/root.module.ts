// 1. Default / Auto Bootstraping
// import { NgModule } from "@angular/core";
// import { HelloComponent } from "./hello.component";
// import { BrowserModule } from "@angular/platform-browser";

// @NgModule({
//     imports: [BrowserModule],
//     declarations: [HelloComponent],
//     bootstrap: [HelloComponent]
// })
// export class RootModule { }

// 2. Custom / Manual Bootstraping
// import { NgModule, ApplicationRef } from "@angular/core";
// import { HelloComponent } from "./hello.component";
// import { BrowserModule } from "@angular/platform-browser";

// @NgModule({
//     imports: [BrowserModule],
//     declarations: [HelloComponent],
//     entryComponents: [HelloComponent]
// })
// export class RootModule { 
//     ngDoBootstrap(appRef: ApplicationRef){
//         const dynamicComponent = document.querySelector('#dynamicComponent');
//         dynamicComponent.textContent = "Loaded...";

//         const helloTag = document.createElement('hello');
//         dynamicComponent.appendChild(helloTag);

//         appRef.bootstrap(HelloComponent);
//     }
// }

// 3. Angular Elements (Ng6)
import { NgModule, ApplicationRef, Injector } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { createCustomElement } from "@angular/elements";

import { HelloComponent } from "./hello.component";

@NgModule({
    imports: [BrowserModule],
    declarations: [HelloComponent],
    entryComponents: [HelloComponent]
})
export class RootModule {
    constructor(private injector: Injector) { }

    ngDoBootstrap(appRef: ApplicationRef) {
        const HelloElement = createCustomElement(HelloComponent, { injector: this.injector });
        customElements.define('my-hello', HelloElement);
    }
}