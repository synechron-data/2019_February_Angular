import { Component } from "@angular/core";

@Component({
    selector: 'c-one',
    template: `
        <h1 class="text-info">Hello from Component One - Module One!</h1>
        <c-two>Using in Module One - Component One</c-two>
        <hr/>
        `
})
export class COneComponent { }