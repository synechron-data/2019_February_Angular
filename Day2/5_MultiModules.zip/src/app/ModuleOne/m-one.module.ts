import { NgModule } from '@angular/core';
import { COneComponent } from './c-one.component';
import { MTwoModule } from '../ModuleTwo/m-two.module';

@NgModule({
    imports: [MTwoModule],
    declarations: [COneComponent],
    exports: [COneComponent]
})
export class MOneModule { }
