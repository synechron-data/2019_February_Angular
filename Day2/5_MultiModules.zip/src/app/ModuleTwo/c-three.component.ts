import { Component } from "@angular/core";

@Component({
    selector: 'c-three',
    template: `
        <h1 class="text-success">Hello from Component Three - Module Two!</h1>
    `
})
export class CThreeComponent { }