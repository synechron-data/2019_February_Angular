import { NgModule } from '@angular/core';
import { CTwoComponent } from './c-two.component';
import { CThreeComponent } from './c-three.component';
import { MTThreeModule } from '../ModuleThree/m-three.module';

@NgModule({
    imports: [MTThreeModule],
    declarations: [CTwoComponent, CThreeComponent],
    exports: [CTwoComponent]
})
export class MTwoModule { }
