import { Component } from "@angular/core";

@Component({
    selector: 'c-four',
    template: `
        <h1 class="text-success">Hello from Component Four - Module Three!</h1>
    `
})
export class CFourComponent { }