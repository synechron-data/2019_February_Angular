import { NgModule } from '@angular/core';
import { CFourComponent } from './c-four.component';

@NgModule({
    declarations: [CFourComponent],
    exports: [CFourComponent]
})
export class MTThreeModule { }
