import { Component } from "@angular/core";

@Component({
    selector: 'c-one',
    styleUrls: ['./c-one.component.css'],
    template: `
        <h1 class="text-info">Hello from Component One</h1>
        <h1 class="card">From Component One</h1>
    `
})
export class COneComponent { }