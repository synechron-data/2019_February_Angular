import { Component } from "@angular/core";

@Component({
    selector: 'hello',
    template: `
        <h1 class="text-info">Hello World!</h1>
    `
})
export class HelloComponent { }