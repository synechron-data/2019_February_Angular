import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { UsersService } from '../../services/users.service';

@Component({
    templateUrl: 'admin.component.html',
    providers: [UsersService]
})

export class AdminComponent implements OnInit, OnDestroy {
    users: Array<any>;

    message: string;
    gau_Subsciption: Subscription;

    constructor(private _uService: UsersService) {
        this.message = "Getting Data from the server, please wait......";
    }

    ngOnInit() { 
        this.gau_Subsciption = this._uService.getAllUsers().subscribe((resData) => {
            this.users = resData.users;
            this.message = "";
        }, (err: string) => {
            this.message = err;
        });
    }

    ngOnDestroy(): void {
        this.gau_Subsciption.unsubscribe();
    }
}