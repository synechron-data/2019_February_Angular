import { Routes } from "@angular/router";
import { HomeComponent } from "./components/home/home.component";
import { AboutComponent } from "./components/about/about.component";
import { AuthorsRootComponent } from "./authors-module/components/authors-root/authors-root.component";
import { NotFoundComponent } from "./components/not-found/not-found.component";
import { ProductsComponent } from "./products/products.component";
import { NotSelectedComponent } from "./products/ns.component";
import { ProductDetailsComponent } from "./products/pd.component";
import { AdminComponent } from "./components/admin/admin.component";
import { LoginComponent } from "./components/login/login.component";
import { AuthGuard } from "./services/authguard.service";

export const routes: Routes = [
    { path: '', component: HomeComponent },
    { path: 'about', component: AboutComponent },
    { path: 'authors', component: AuthorsRootComponent },
    { 
        path: 'products', 
        component: ProductsComponent,
        children: [
            { path: '', component: NotSelectedComponent },
            { path: ':id', component: ProductDetailsComponent }
        ] 
    },
    { path: 'lazy', loadChildren: './lazy-module/lazy.module#LazyModule'},
    { path: 'login', component: LoginComponent },
    { path: 'admin', component: AdminComponent, canActivate:[AuthGuard] },
    { path: '**', component: NotFoundComponent }
];