import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { RouterModule } from "@angular/router";

import { RootComponent } from "./components/root/root.component";
import { BSNavigationComponent } from "./components/bs-nav/bs-nav.component";

import { routes } from "./root.routes";
import { HomeComponent } from "./components/home/home.component";
import { AboutComponent } from "./components/about/about.component";
import { AuthorsModule } from "./authors-module/authors.module";
import { NotFoundComponent } from "./components/not-found/not-found.component";
import { ProductsComponent } from "./products/products.component";
import { NotSelectedComponent } from "./products/ns.component";
import { ProductDetailsComponent } from "./products/pd.component";
import { AdminComponent } from "./components/admin/admin.component";
import { LoginComponent } from "./components/login/login.component";
import { AuthenticationService } from "./services/authentication.service";
import { AuthGuard } from "./services/authguard.service";
import { TokenInterceptor } from "./services/http-interceptor.service";

@NgModule({
    imports: [BrowserModule, FormsModule, ReactiveFormsModule,
        HttpClientModule,
        AuthorsModule,
        RouterModule.forRoot(routes)],
    declarations: [RootComponent, BSNavigationComponent, HomeComponent,
        AboutComponent, NotFoundComponent,
        ProductsComponent, NotSelectedComponent, ProductDetailsComponent,
        AdminComponent, LoginComponent],
    providers: [
        AuthenticationService,
        AuthGuard,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: TokenInterceptor,
            multi: true
        }
    ],
    bootstrap: [RootComponent]
})
export class RootModule { }