import { Component, OnInit } from '@angular/core';

@Component({
    template: `
        <h2 class="text-warning">Lazy Loaded Component One</h2>
    `
})

export class LazyOneComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}