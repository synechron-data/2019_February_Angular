import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { lazyRoutes } from './lazy.routes';
import { LazyOneComponent } from './components/lazy-one.component';

@NgModule({
    imports: [RouterModule.forChild(lazyRoutes)],
    exports: [RouterModule],
    declarations: [LazyOneComponent],
})
export class LazyModule { }
