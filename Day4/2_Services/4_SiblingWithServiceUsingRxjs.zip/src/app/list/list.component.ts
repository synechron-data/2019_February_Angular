import { Component, OnInit } from '@angular/core';
import { Author } from '../models/app.author';
import { AuthorsService } from '../services/authors.service';

@Component({
    selector: 'author-list',
    templateUrl: 'list.component.html',
    styleUrls: ['./list.component.css']
})

export class AuthorListComponent implements OnInit {
    list: Array<Author>;
    selectedAuthor: Author;

    constructor(private _aService: AuthorsService) { }

    ngOnInit() {
        this.list = this._aService.Authors;
    }

    selectAuthor(a: Author) {
        this._aService.SelectedAuthor = a;
        this.selectedAuthor = this._aService.SelectedAuthor;
    }

    isSelected(a: Author) {
        return this.selectedAuthor === a;
    }
}