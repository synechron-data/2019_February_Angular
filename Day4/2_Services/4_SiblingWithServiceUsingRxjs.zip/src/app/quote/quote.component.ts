import { Component, OnInit, OnDestroy } from '@angular/core';
import { AuthorsService } from '../services/authors.service';
import { Author } from '../models/app.author';
import { Subscription } from 'rxjs';

@Component({
    selector: 'quote',
    templateUrl: 'quote.component.html',
    styleUrls: ['./quote.component.css']
})

export class QuoteComponent implements OnInit, OnDestroy {
    selectedAuthor: Author;
    sAuthorChangedSub: Subscription;

    constructor(private _aSerive: AuthorsService) { }

    ngOnInit() {
        this.sAuthorChangedSub = this._aSerive.SelectedAuthorChanged.subscribe(() => {
            this.selectedAuthor = this._aSerive.SelectedAuthor;
        });
    }

    ngOnDestroy(): void {
        this.sAuthorChangedSub.unsubscribe();
    }
}