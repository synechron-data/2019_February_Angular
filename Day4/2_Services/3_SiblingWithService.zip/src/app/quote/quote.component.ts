import { Component, OnInit } from '@angular/core';
import { AuthorsService } from '../services/authors.service';
import { Author } from '../models/app.author';

@Component({
    selector: 'quote',
    templateUrl: 'quote.component.html',
    styleUrls: ['./quote.component.css']
})

export class QuoteComponent implements OnInit {
    selectedAuthor: Author;

    constructor(private _aSerive: AuthorsService) { }

    ngOnInit() { }

    get(){
        this.selectedAuthor = this._aSerive.SelectedAuthor;
    }
}